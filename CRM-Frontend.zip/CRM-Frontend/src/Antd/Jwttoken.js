import React, { useEffect, useState } from 'react';

function isTokenExpired(token) {
  if (!token) {
    return true;
  }

  const tokenParts = token.split('.');
  console.log("tokenParts: ",tokenParts);
  if (tokenParts.length !== 3) {
    return true;
  }

  try {
    const payload = JSON.parse(atob(tokenParts[1])); 
    if (!payload || !payload.exp) {
      return true; 
    }
    const expirationTime = payload.exp * 1000; 
    console.log(expirationTime);
    return expirationTime < Date.now();
  } catch (error) {
    console.error('Error decoding token:', error);
    return true; 
  }
}

function Jwttoken() {
  const [isTokenExpiredState, setIsTokenExpiredState] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('jwttoken');
    const isExpired = isTokenExpired(token);
    setIsTokenExpiredState(isExpired);
  }, []);

  return (
    <div>
      {isTokenExpiredState ? (
        <p>Token is expired or invalid.</p>
      ) : (
        <p>Token is still valid.</p>
      )}
    </div>
  );
}

export default Jwttoken;
